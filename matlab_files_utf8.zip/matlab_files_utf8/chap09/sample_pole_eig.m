% sample_pole_eig
% システムの極（関数 pole, eig の使用例）

arm_ss

pole(sys)

eig(A)

