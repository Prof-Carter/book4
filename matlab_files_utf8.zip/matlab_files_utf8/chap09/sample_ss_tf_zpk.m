% sample_ss_tf_zpk
% システムのモデルの表現の変換（関数 ss, tf, zpk の使用例）

arm_ss

sysP = tf(sys)

sysP = zpk(sys)

