% n 次方程式の数値解（関数 roots の使用例）

clear
format compact

roots([1 2 -15 0])

roots([4 8])